"""Makes fake 'room' photos so you can test without real photos."""
import cv2, numpy as np, os
rng = np.random.default_rng(1)
out = os.path.join(os.path.dirname(__file__), "samples"); os.makedirs(out, exist_ok=True)

def room():
    img = np.full((500, 800, 3), (180, 190, 200), np.uint8)
    noise = rng.integers(0, 40, img.shape, dtype=np.uint8); img = cv2.add(img, noise)
    cv2.rectangle(img, (0, 330), (800, 500), (90, 120, 150), -1)           # floor
    cv2.rectangle(img, (80, 60), (240, 200), (60, 60, 160), -1)           # picture
    for i in range(0, 800, 40): cv2.line(img, (i, 0), (i, 330), (150, 160, 170), 1)
    cv2.rectangle(img, (300, 240), (620, 330), (40, 70, 110), -1)         # desk
    return img
def laptop(img, x=380, y=190):
    cv2.rectangle(img, (x, y), (x + 120, y + 50), (30, 30, 30), -1)
    cv2.rectangle(img, (x + 10, y + 8), (x + 110, y + 42), (200, 120, 40), -1)
    cv2.line(img, (x + 15, y + 15), (x + 100, y + 35), (255, 255, 255), 2)
    cv2.rectangle(img, (x - 10, y + 50), (x + 130, y + 58), (20, 20, 20), -1)

def shift(img):  # slight camera rotation + brightness change
    M = cv2.getRotationMatrix2D((400, 250), 2.5, 1.03); M[:, 2] += (10, -6)
    return cv2.convertScaleAbs(cv2.warpAffine(img, M, (800, 500), borderMode=cv2.BORDER_REPLICATE), alpha=0.9, beta=-8)

base = room(); with_l = base.copy(); laptop(with_l)
cv2.imwrite(f"{out}/removed_before.jpg", with_l); cv2.imwrite(f"{out}/removed_after.jpg", shift(base))
cv2.imwrite(f"{out}/added_before.jpg", base); cv2.imwrite(f"{out}/added_after.jpg", shift(with_l))
mv = base.copy(); laptop(mv, 470, 190)
cv2.imwrite(f"{out}/same_before.jpg", base); cv2.imwrite(f"{out}/same_after.jpg", shift(base))
cv2.imwrite(f"{out}/moved_before.jpg", with_l); cv2.imwrite(f"{out}/moved_after.jpg", shift(mv))
