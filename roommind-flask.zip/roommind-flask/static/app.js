const $ = (id) => document.getElementById(id);
const form = $("form");

// live preview of chosen files
for (const name of ["before", "after"]) {
  form.elements[name].addEventListener("change", (e) => {
    const f = e.target.files[0], img = $("pv-" + name);
    if (f) { img.src = URL.createObjectURL(f); img.style.display = "block"; }
  });
}
form.elements.sensitivity.addEventListener("input", (e) => {
  $("sv").textContent = Number(e.target.value).toFixed(2);
});

form.addEventListener("submit", async (e) => {
  e.preventDefault();
  $("error").hidden = true;
  $("go").disabled = true; $("go").textContent = "Analyzing...";
  try {
    const res = await fetch("/analyze", { method: "POST", body: new FormData(form) });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || "Something went wrong.");
    render(data);
  } catch (err) {
    $("error").textContent = err.message; $("error").hidden = false;
  } finally {
    $("go").disabled = false; $("go").textContent = "Analyze room";
  }
});

function render(d) {
  $("results").hidden = false;
  const b = $("banner");
  b.className = "banner " + (d.status === "secure" ? "secure" : "alert");
  b.textContent = (d.status === "secure" ? "SECURE - " : "ALERT - ") + d.summary +
                  ` (${d.changed_percent}% of pixels changed)`;
  $("out-before").src = d.images.before;
  $("out-annotated").src = d.images.annotated;
  $("out-heat").src = d.images.heatmap;
  const ul = $("changes"); ul.innerHTML = "";
  for (const c of d.changes) {
    const li = document.createElement("li");
    li.className = c.type;
    li.textContent = `#${c.id} ${c.type.toUpperCase()}: ${c.message} (${c.area_percent}% of the photo)`;
    ul.appendChild(li);
  }
  $("meta").textContent = d.alignment.aligned
    ? `Photos aligned using ${d.alignment.inliers} matching feature points.`
    : "Could not align the photos (too few matching features) - results may be noisy.";
  $("results").scrollIntoView({ behavior: "smooth" });
}
