import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import app
S = os.path.join(os.path.dirname(__file__), "samples")

def run(name, sens=0.5):
    c = app.test_client()
    with open(f"{S}/{name}_before.jpg", "rb") as a, open(f"{S}/{name}_after.jpg", "rb") as b:
        r = c.post("/analyze", data={"before": (a, "a.jpg"), "after": (b, "b.jpg"), "sensitivity": sens},
                   content_type="multipart/form-data")
    return r.status_code, r.get_json()

def test_same_is_secure():
    code, d = run("same"); assert code == 200 and d["status"] == "secure", d["changes"]
def test_removed():
    code, d = run("removed"); assert d["status"] == "changes_detected" and any(c["type"] == "removed" for c in d["changes"]), d["changes"]
def test_added():
    code, d = run("added"); assert any(c["type"] == "added" for c in d["changes"]), d["changes"]
def test_moved_detected():
    code, d = run("moved"); assert d["status"] == "changes_detected"
def test_missing_file():
    assert app.test_client().post("/analyze", data={}).status_code == 400

if __name__ == "__main__":      # run with: python tests/test_app.py   (no pytest needed)
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            try: fn(); print("PASS", name)
            except AssertionError as e: print("FAIL", name, e)
