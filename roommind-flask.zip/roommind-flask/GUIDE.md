# RoomMind (Flask) - Step-by-Step Build Guide

Goal: upload a BEFORE and an AFTER photo of a room; the app aligns them, finds what changed, and labels each change as removed / added / moved.

Stack: **Python + Flask + OpenCV** (back end) and **HTML + CSS + JavaScript** (front end). No database and no API keys are needed.

---
## PART 0 - Setup
1. Install Python 3.10+ and VS Code.
2. In a terminal:
   ```
   mkdir roommind && cd roommind
   python -m venv venv
   venv\Scripts\activate          (Windows)    |   source venv/bin/activate   (Mac/Linux)
   pip install flask opencv-python-headless numpy
   pip freeze > requirements.txt
   ```
3. Create the folders: `templates/`, `static/`, `tests/`.

## PART 1 - Back end: computer vision (`detector.py`)
Build and test each function ALONE (in a scratch script with `cv2.imshow`/`cv2.imwrite`) before moving on.

**Step 1 - Resize.** Different photos have different sizes. Resize both to 800px wide with `cv2.resize`.

**Step 2 - Alignment** (`align_images`). You will never hold the phone in exactly the same spot, so the AFTER photo must be lined up with the BEFORE photo.
- `cv2.ORB_create(2000)` finds 2000 keypoints (corners/edges) in each image.
- `cv2.BFMatcher` matches keypoints between the images.
- `cv2.findHomography(..., cv2.RANSAC)` computes a 3x3 matrix H, ignoring wrong matches (outliers).
- `cv2.warpPerspective` applies H to AFTER.
- Warping leaves black borders, so we also warp an all-white image to learn which pixels are valid, and ignore the rest.
- If fewer than 12 matches survive RANSAC, skip the warp and tell the user.

**Step 3 - Lighting** (`normalize_light`). Convert to LAB colour space and make the L (lightness) channel of AFTER have the same mean and standard deviation as BEFORE. This stops "it got darker" from counting as a change.

**Step 4 - Change mask** (`change_mask`).
Blur -> `cv2.absdiff` -> grayscale -> `cv2.threshold` -> morphology (OPEN removes specks, CLOSE fills holes). Sensitivity controls the threshold (70 strict ... 15 sensitive).

**Step 5 - Regions** (`find_regions`). `cv2.findContours` turns white blobs into shapes; keep blobs bigger than 0.2% of the image and take their bounding boxes.

**Step 6 - Classify** (`classify_region`). Measure edge density (Canny) inside each box in BEFORE and AFTER:
- more detail before -> **removed**
- more detail after -> **added**
- similar -> **moved/changed**

**Step 7 - `analyze()`** chains steps 1-6, draws coloured boxes, makes a heatmap (`cv2.applyColorMap`), and returns everything as a dict (images as base64 so no files are saved).

## PART 2 - Back end: web server (`app.py`)
1. `Flask(__name__)` creates the app.
2. `GET /` renders `templates/index.html`.
3. `POST /analyze` reads `request.files["before"]` and `["after"]` and `request.form["sensitivity"]`, validates them (both present, image type, size <= 16 MB), calls `analyze()`, and returns `jsonify(result)`.
4. Return a JSON error with status 400 for bad input - the front end shows it.

## PART 3 - Front end
**`templates/index.html`** - a `<form>` with two `<input type="file">`, a range slider, and a results section (hidden at first).
**`static/style.css`** - dark theme, 2-column upload area, 3-column result grid, one media query for phones.
**`static/app.js`**
1. Show a live preview of each chosen file with `URL.createObjectURL`.
2. On submit: `fetch("/analyze", {method:"POST", body:new FormData(form)})`.
3. Show the SECURE/ALERT banner, the three images, and the list of changes.
4. Handle errors with `try/catch` and disable the button while waiting.

## PART 4 - Run it
```
python app.py
```
Open http://127.0.0.1:5000

## PART 5 - Test
```
python tests/make_samples.py     # makes fake rooms: same / removed / added / moved
python tests/test_app.py         # should print PASS x5
```
Then test with REAL photos: same room, phone moved a bit, laptop removed.

## PART 6 - Optional upgrade: neural network (your stretch goal)
Classical OpenCV is explainable, but a Siamese CNN handles hard cases better. Your AI Studio zip already contains `ml/model.py`, `dataset.py`, `train.py`. To integrate:
1. `pip install torch`, run `python ml/train.py`.
2. In `detector.py`, replace `change_mask()` with a call to the model's forward pass.
3. Keep alignment and lighting steps - the network benefits from them too.
Only do this if you can explain every layer; otherwise present it honestly as future work.

## PART 7 - Deploy (optional)
`pip install gunicorn`, then deploy to Render/Railway with start command `gunicorn app:app`.

## Known limitations (mention these in your report - examiners like honesty)
- Needs a roughly similar viewpoint; very different angles fail alignment.
- Plain, textureless walls give few ORB keypoints.
- Moving shadows/reflections can cause false alarms.
- "Moved vs removed vs added" is a heuristic, not object recognition.

## Viva questions to prepare
1. Why a homography and not a simple shift? 2. What does RANSAC do? 3. Why LAB instead of RGB? 4. What do OPEN/CLOSE morphology do? 5. Why can classification be wrong? 6. How would you reduce false positives?
