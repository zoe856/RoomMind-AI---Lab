"""
detector.py - the computer-vision "brain" of RoomMind.

Pipeline (each function = one step you can explain to your teacher):
  1. align_images      : ORB features + RANSAC homography -> warp AFTER onto BEFORE
  2. normalize_light   : match brightness/contrast in LAB colour space
  3. change_mask       : blur -> absdiff -> threshold -> morphology
  4. find_regions      : contours -> bounding boxes
  5. classify_region   : removed / added / moved (edge-density heuristic)
  6. analyze           : runs everything, returns a dict for the web app
"""
import base64
import cv2
import numpy as np

WORK_W = 800  # all images are resized to this width for speed & consistency


def resize(img, width=WORK_W):
    h, w = img.shape[:2]
    return cv2.resize(img, (width, int(h * width / w)), interpolation=cv2.INTER_AREA)


# ---------- Step 1: alignment ----------
def align_images(before, after):
    """Warp `after` onto `before`. Returns (aligned, info, valid_mask)."""
    g1 = cv2.cvtColor(before, cv2.COLOR_BGR2GRAY)
    g2 = cv2.cvtColor(after, cv2.COLOR_BGR2GRAY)
    orb = cv2.ORB_create(2000)
    k1, d1 = orb.detectAndCompute(g1, None)
    k2, d2 = orb.detectAndCompute(g2, None)
    info = {"aligned": False, "keypoints": [len(k1), len(k2)], "inliers": 0}
    full = np.full(g1.shape, 255, np.uint8)       # "every pixel is valid" mask
    if d1 is None or d2 is None or len(k1) < 10 or len(k2) < 10:
        return after, info, full

    matcher = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)
    matches = sorted(matcher.match(d2, d1), key=lambda m: m.distance)[:300]
    if len(matches) < 10:
        return after, info, full

    src = np.float32([k2[m.queryIdx].pt for m in matches]).reshape(-1, 1, 2)
    dst = np.float32([k1[m.trainIdx].pt for m in matches]).reshape(-1, 1, 2)
    H, mask = cv2.findHomography(src, dst, cv2.RANSAC, 4.0)
    if H is None:
        return after, info, full

    inliers = int(mask.sum())
    info["inliers"] = inliers
    if inliers < 12:           # too few good matches -> don't trust the warp
        return after, info, full
    h, w = before.shape[:2]
    info["aligned"] = True
    warped = cv2.warpPerspective(after, H, (w, h))
    # which pixels really came from the AFTER photo? (warp leaves black borders)
    valid = cv2.warpPerspective(full, H, (w, h))
    valid = cv2.erode(valid, np.ones((15, 15), np.uint8))
    return warped, info, valid


# ---------- Step 2: lighting ----------
def normalize_light(before, after):
    """Match mean/std of the L (lightness) channel of `after` to `before`."""
    a = cv2.cvtColor(after, cv2.COLOR_BGR2LAB).astype(np.float32)
    b = cv2.cvtColor(before, cv2.COLOR_BGR2LAB).astype(np.float32)
    la, lb = a[:, :, 0], b[:, :, 0]
    a[:, :, 0] = (la - la.mean()) / (la.std() + 1e-6) * lb.std() + lb.mean()
    a = np.clip(a, 0, 255).astype(np.uint8)
    return cv2.cvtColor(a, cv2.COLOR_LAB2BGR)


# ---------- Step 3: change mask ----------
def change_mask(before, after, sensitivity, valid):
    """sensitivity 0..1 (higher = notices smaller changes)."""
    b = cv2.GaussianBlur(before, (7, 7), 0)
    a = cv2.GaussianBlur(after, (7, 7), 0)
    diff = cv2.absdiff(b, a)
    gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
    thresh = int(70 - 55 * sensitivity)          # 70 (strict) .. 15 (sensitive)
    _, mask = cv2.threshold(gray, thresh, 255, cv2.THRESH_BINARY)
    k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (9, 9))
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, k)    # remove specks
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, k, iterations=2)  # fill holes
    mask = cv2.bitwise_and(mask, valid)    # ignore the black border from warping
    return mask, cv2.bitwise_and(gray, valid)


# ---------- Step 4: regions ----------
def find_regions(mask, min_area_frac=0.002):
    h, w = mask.shape
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    boxes = []
    for c in contours:
        if cv2.contourArea(c) >= min_area_frac * h * w:
            boxes.append(cv2.boundingRect(c))
    return sorted(boxes, key=lambda b: b[2] * b[3], reverse=True)[:10]


# ---------- Step 5: classify ----------
def _detail(img, box):
    x, y, w, h = box
    roi = cv2.cvtColor(img[y:y + h, x:x + w], cv2.COLOR_BGR2GRAY)
    return float(cv2.Canny(roi, 60, 160).mean()) / 255.0   # edge density


def classify_region(before, after, box):
    """More detail before -> object disappeared. More after -> appeared."""
    eb, ea = _detail(before, box), _detail(after, box)
    if eb > ea * 1.3 and eb > 0.02:
        return "removed", "Something that was here is now missing."
    if ea > eb * 1.3 and ea > 0.02:
        return "added", "A new object appeared here."
    return "moved", "Something here was moved or changed."


# ---------- Step 6: everything together ----------
def _b64(img):
    ok, buf = cv2.imencode(".jpg", img, [cv2.IMWRITE_JPEG_QUALITY, 88])
    return "data:image/jpeg;base64," + base64.b64encode(buf).decode()


COLORS = {"removed": (60, 60, 230), "added": (60, 190, 60), "moved": (0, 165, 255)}


def analyze(before_bytes, after_bytes, sensitivity=0.5):
    before = cv2.imdecode(np.frombuffer(before_bytes, np.uint8), cv2.IMREAD_COLOR)
    after = cv2.imdecode(np.frombuffer(after_bytes, np.uint8), cv2.IMREAD_COLOR)
    if before is None or after is None:
        raise ValueError("Could not read one of the images.")

    before = resize(before)
    after = cv2.resize(resize(after), (before.shape[1], before.shape[0]))

    aligned, info, valid = align_images(before, after)
    aligned = normalize_light(before, aligned)
    mask, gray = change_mask(before, aligned, sensitivity, valid)
    boxes = find_regions(mask)

    annotated = aligned.copy()
    changes = []
    for i, box in enumerate(boxes, 1):
        kind, text = classify_region(before, aligned, box)
        x, y, w, h = box
        cv2.rectangle(annotated, (x, y), (x + w, y + h), COLORS[kind], 3)
        cv2.putText(annotated, str(i), (x + 4, y + 22), cv2.FONT_HERSHEY_SIMPLEX,
                    0.8, COLORS[kind], 2, cv2.LINE_AA)
        area_pct = round(100.0 * w * h / (before.shape[0] * before.shape[1]), 1)
        changes.append({"id": i, "type": kind, "message": text,
                        "box": [x, y, w, h], "area_percent": area_pct})

    heat = cv2.applyColorMap(cv2.normalize(gray, None, 0, 255, cv2.NORM_MINMAX),
                             cv2.COLORMAP_JET)
    changed_pct = round(100.0 * float((mask > 0).mean()), 2)
    return {
        "status": "changes_detected" if changes else "secure",
        "summary": (f"{len(changes)} change(s) found." if changes
                    else "Room looks unchanged."),
        "changed_percent": changed_pct,
        "alignment": info,
        "changes": changes,
        "images": {"before": _b64(before), "annotated": _b64(annotated),
                   "heatmap": _b64(heat)},
    }
