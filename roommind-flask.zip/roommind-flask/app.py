"""app.py - Flask backend. Run with:  python app.py"""
from flask import Flask, render_template, request, jsonify
from detector import analyze

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024   # 16 MB upload limit
ALLOWED = {"image/jpeg", "image/png", "image/webp"}


@app.get("/")
def index():
    return render_template("index.html")


@app.post("/analyze")
def analyze_route():
    before, after = request.files.get("before"), request.files.get("after")
    if not before or not after:
        return jsonify(error="Please upload both a BEFORE and an AFTER photo."), 400
    if before.mimetype not in ALLOWED or after.mimetype not in ALLOWED:
        return jsonify(error="Only JPG, PNG or WEBP images are allowed."), 400
    try:
        sens = min(max(float(request.form.get("sensitivity", 0.5)), 0), 1)
        return jsonify(analyze(before.read(), after.read(), sens))
    except ValueError as e:
        return jsonify(error=str(e)), 400


@app.errorhandler(413)
def too_big(_):
    return jsonify(error="File too large (max 16 MB)."), 413


if __name__ == "__main__":
    app.run(debug=True, port=5000)
